export class Jobs {
  _id: string;
    Title: string;
    position: string;
    description: string;
    date: Date;
}
