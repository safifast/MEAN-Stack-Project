import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { HttpModule } from '@angular/http';
import 'rxjs/add/operator/map';
import { tokenNotExpired } from 'angular2-jwt';

@Injectable()
export class AuthService {
  authToken: any;
  user: any;
  isDev: boolean;
  constructor(private http: Http) {
      this.isDev = false;  // Change to false before deployment
      }

  registerUser(user) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('http://localhost:3000/users/register', user, {headers: headers})
      .map(res => res.json());
  }

  registerProfile(user) {
    let headers = new Headers();
    this.loadToken();
    headers.append('Authorization', this.authToken);
    headers.append('Content-Type', 'application/json');
    user={ "client_id":"K4qGCKPj5aFTMlrG07jaaFs58PMSiYYt","client_secret":"qDgq1VnkVJaNPIJLPGZGV3Y8nSrvSxTEbywYV189hbClagGhBk5sa6j4SDsY9VWy","audience":"https://dev-wruokhk5.auth0.com/api/v2/","grant_type":"client_credentials"};
    return this.http.post('http://localhost:3000/users/RegisterProfiles', user, {headers: headers})
      .map(res => res.json());
  }

  registerJobs(job) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('http://localhost:3000/users/post', job, {headers: headers})
      .map(res => res.json());
  }

  authenticateUser(user) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('http://localhost:3000/users/authenticate', user, {headers: headers})
      .map(res => res.json());
  }
  passforgot(email) {
    let headers = new Headers();
    //return this.http.get('http://localhost:3000/'+email)
    //.pipe(map((response: any) => response.json()));
    //headers.append('Content-Type', 'application/json');
    return this.http.get('http://localhost:3000/'+email)
      .map(res => res.json());
  }

  getProfile() {
    let headers = new Headers();
    this.loadToken();
    headers.append('Authorization', this.authToken);
    headers.append('Content-Type', 'application/json');
    return this.http.get('http://localhost:3000/users/getprofile', {headers: headers})
      .map(res => res.json());
  }

  getJobs() {
    let headers = new Headers();
    this.loadToken();
    headers.append('Content-Type', 'application/json');
    return this.http.get('http://localhost:3000/users/getJobs', {headers: headers})
      .map(res => res.json());
  }

  storeUserData(token, user) {
    localStorage.setItem('id_token', token);
    localStorage.setItem('user', JSON.stringify(user));
    this.authToken = token;
    this.user = user;
  }

  loadToken() {
    const token = localStorage.getItem('id_token');
    this.authToken = token;
  }

  loggedIn() {
    return tokenNotExpired('id_token');
  }

  logout() {
    this.authToken = null;
    this.user = null;
    localStorage.clear();
  }
}
