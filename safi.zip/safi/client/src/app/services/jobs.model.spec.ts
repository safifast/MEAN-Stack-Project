import { Jobs } from './jobs.model';

describe('Jobs', () => {
  it('should create an instance', () => {
    expect(new Jobs()).toBeTruthy();
  });
});
