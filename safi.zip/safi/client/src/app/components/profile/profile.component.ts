import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { ValidateService } from '../../services/validate.service';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Router } from '@angular/router';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  user:object;
  name: String;
  email: String;
  qualification: String;
  Intrests: String;
  Company_name: String;
  Position: String;
  Mobile_number: String;
  Work_address: String;
  constructor(private validateService: ValidateService,
    private authService: AuthService,
    private router: Router,
    private flashMessage: FlashMessagesService) { }

  ngOnInit() {
    this.authService.getProfile().subscribe(profile => {
      console.log(profile);
    },
    err => {
      console.log(err);
      return false;
     });
  }
  onProfileSubmit() {
    var user = {
      name: this.name,
      email: this.email,
      qualification: this.qualification,
      Intrests: this.Intrests,
      Company_name: this.Company_name,
      Position: this.Position,
      Mobile_number: this.Mobile_number,
      Work_address: this.Work_address
    }
    this.authService.registerProfile(user).subscribe(data => {
    if(data.success) {
      this.flashMessage.show('You have updated Your Profile Successfully', {cssClass: 'alert-success', timeout: 3000});
      this.router.navigate(['/profile']);
    } else {
      this.flashMessage.show('Something went wrong', {cssClass: 'alert-danger', timeout: 3000});
      this.router.navigate(['/profile']);
    }
  });
  }
}
