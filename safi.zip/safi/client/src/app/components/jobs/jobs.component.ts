import { Component, OnInit } from '@angular/core';
import { ValidateService } from '../../services/validate.service';
import { AuthService } from '../../services/auth.service';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Router } from '@angular/router';
@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.css']
})
export class JobsComponent implements OnInit {
  JobTitle: String;
  Description: String;
  posts:Object;
  constructor(private validateService: ValidateService,
    private authService: AuthService,
    private router: Router,
    private flashMessage: FlashMessagesService) { }

  ngOnInit() {
    this.authService.getJobs().subscribe(jobs => {
      this.posts = jobs.data;
      console.log(this.posts);
    },
     err => {
       console.log(err);
       return false;
     });
  }
  onPostSubmit() {
    const job = {
      JobTitle: this.JobTitle,
      Description: this.Description
    }

    // Required Fields
    if(!this.validateService.validateJobs(job)) {
      this.flashMessage.show('Please fill in all fields', {cssClass: 'alert-danger', timeout: 3000});
      return false;
    }

    // Register job
    this.authService.registerJobs(job).subscribe(data => {
    if(data.success) {
      this.flashMessage.show('Job Posted Successfully!', {cssClass: 'alert-success', timeout: 3000});
      this.router.navigate(['/dashboard']);
    } else {
      this.flashMessage.show('Something went wrong', {cssClass: 'alert-danger', timeout: 3000});
      this.router.navigate(['/jobs']);
    }
  });
  }
}
