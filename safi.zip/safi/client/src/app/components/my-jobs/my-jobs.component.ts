import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';


import { JobsService } from '../../services/jobs.service';
import { Jobs } from '../../services/jobs.model';
import { jobs } from 'src/model/job.model';

declare var M: any;

@Component({
  selector: 'app-my-jobs',
  templateUrl: './my-jobs.component.html',
  styleUrls: ['./my-jobs.component.css'],
  providers: [JobsService]
})
export class MyJobsComponent implements OnInit {

  constructor(private JobsService:JobsService) { }

  ngOnInit() {
    this.resetForm();
    this.refreshEmployeeList();
  }
  resetForm(form?: NgForm) {
    if (form)
      form.reset();
    this.JobsService.selectedEmployee = {
      _id: "",
      Title: "",
      position: "",
      description:"",
      date: null
    }
  }

  onSubmit(form: NgForm) {
    if (form.value._id == "") {
      console.log(form.value);
      this.JobsService.postEmployee(form.value).subscribe((res) => {
        this.resetForm(form);
        this.refreshEmployeeList();
        M.toast({ html: 'Saved successfully', classes: 'rounded' });
      });
    }
    else {
      console.log(form.value);
      this.JobsService.putEmployee(form.value).subscribe((res) => {
        this.resetForm(form);
        this.refreshEmployeeList();
        M.toast({ html: 'Updated successfully', classes: 'rounded' });
      });
    }
  }

  refreshEmployeeList() {
    this.JobsService.getEmployeeList().subscribe((res) => {
      this.JobsService.employees = res as Jobs[];
    });
  }

  onEdit(emp: Jobs) {
    this.JobsService.selectedEmployee = emp;
  }

  onDelete(_id: string, form: NgForm) {
    if (confirm('Are you sure to delete this record ?') == true) {
      this.JobsService.deleteEmployee(_id).subscribe((res) => {
        this.refreshEmployeeList();
        this.resetForm(form);
        M.toast({ html: 'Deleted successfully', classes: 'rounded' });
      });
    }
  }
}
