import { profile } from "./profile.model";

export class jobs{
    jobtitle:string;
    //image:string;
    description:string;
    discipline:string;
    experience:number;
    tags:profile[];
    constructor(title:string, discipline:string,description:string,experience:number){
        this.description=description;
        this.experience=experience;
        this.discipline=discipline;
        this.tags=null;
        this.jobtitle=title;
    }
}