export class post{
    title:String;
    subtitle:String;
    description:String;
    postimg:String;
    constructor(title:string, subtitle:string, description:string, postimg:string){
      this.title=title;
      this.subtitle=subtitle;
      this.description=description;
      this.postimg=postimg;
    }
  }