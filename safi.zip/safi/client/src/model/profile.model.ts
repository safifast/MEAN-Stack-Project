export class profile{
    public first_name:string;
    public last_name:string;
    public email:string;
    public image:string;
    public password:string;
    constructor(first:string=null, last:string=null, email:string=null, image:string=null,password:string=null){
        this.first_name= first;
        this.last_name= last;
        this.email= email;
        this.image= image;
        this.password=password;
      }
      setVal(first:string=null, last:string=null, email:string=null, image:string=null,password:string=null){
        
        if(first!=null) this.first_name= first;
        if(last!=null) this.last_name= last;
        if(email!=null) this.email= email;
        if(image!=null) this.image= image;
        if(password!=null) this.password=password;
      }
      check(s:string):boolean{
        if(this.first_name.toLowerCase().includes(s.toLowerCase())){
          return true;
        }else if(this.last_name.toLowerCase().includes(s.toLowerCase())){
          return true;
        }else{
          return false;
        }
      }
      getfirst ():string{
        return this.first_name;
      }
      getlast ():string{
        return this.last_name;
      }
    /*  operator =(profile prof):profile{
        this.first_name= prof.first;
        this.last_name= prof.last;
        this.email= prof.email;
        this.image= prof.image;
        this.password=prof.password;
      }*/
}