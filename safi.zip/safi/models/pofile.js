const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const config = require('../config/database');
// Profile Schema
const ProfileSchema = mongoose.Schema ({
  name: {
    type: String
  },
  email: {
    type: String
  },
  qualification: {
    type: String
  },
  Intrests: {
    type: String
  },
  Company_name: {
    type: String
  },
  Position: {
    type: String
  },
  Mobile_number: {
    type: String
  },
  Work_address: {
    type: String
  }
});

const Profile = module.exports = mongoose.model('Profile', ProfileSchema);

module.exports.getProfileById = function(id, callback) {
  Profile.findById(id, callback);
}

module.exports.getProfileByProfilename = function(Profilename, callback) {
  const query = {Profilename: Profilename}
  Profile.findOne(query, callback);
}

module.exports.addProfile = function(newProfile, callback) {
  bcrypt.genSalt(10, (err, salt) => {
    bcrypt.hash(newProfile.password, salt, (err, hash) => {
      if(err) throw err;
      newProfile.password = hash;
      newProfile.save(callback);
    });
  });
}

module.exports.comparePassword = function(candidatePassword, hash, callback) {
  bcrypt.compare(candidatePassword, hash, (err, isMatch) => {
    if(err) throw err;
    callback(null, isMatch);
  });
}
