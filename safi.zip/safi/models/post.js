const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const config = require('../config/database');

// Post Schema
const PostSchema = mongoose.Schema ({
  JobTitle: {
    type: String
  },
  Description: {
    type: String,
    required: true
  },
  
});

const Post = module.exports = mongoose.model('Post', PostSchema);

module.exports.getPostById = function(id, callback) {
  Post.findById(id, callback);
}

module.exports.getPostByJobTitle = function(JobTitle, callback) {
  const query = {JobTitle: JobTitle}
  Post.findOne(query, callback);
}

module.exports.addPost = function(newPost, callback) {
      newPost.save(callback);
}

