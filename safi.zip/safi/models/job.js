const mongoose = require('mongoose');

// var Employee = mongoose.model('Employee', {
var Job = mongoose.model('Jobs', {
    Title: { type: String },
    position: { type: String },
    description: { type: String },
    date: { type: Date }
});

module.exports = { Job };