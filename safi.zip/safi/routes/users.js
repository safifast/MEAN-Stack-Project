var express = require('express');
var secured = require('../lib/middleware/secured');
var router = express.Router();
const passport = require('passport');
const jwt = require('jsonwebtoken');
const config = require('../config/database');
const User = require ('../models/user');
const Post = require ('../models/post');
const Profile = require ('../models/pofile');
/* GET user profile. */
router.get('/user', secured(), function (req, res, next) {
  const { _raw, _json, ...userProfile } = req.user;
  console.log(userProfile);
  res.send("Thanks Allah");
  });




//Register
router.post('/post', (req, res, next) => {
  let newPost = new Post ({
    JobTitle: req.body.JobTitle,
    Description: req.body.Description
  });

Post.addPost(newPost, (err, post) => {
  if(err) {
    res.json({success: false, msg: 'Failed to add Post'});
  } else {
    res.json({success: true, msg: 'Post Registered'});
  }
});
});
  router.post('/register', (req, res, next) => {
    let newUser = new User ({
      name: req.body.name,
      email: req.body.email,
      username: req.body.username,
      password: req.body.password
    });
  
  User.addUser(newUser, (err, user) => {
    if(err) {
      res.json({success: false, msg: 'Failed to register user'});
    } else {
      res.json({success: true, msg: 'User registered'});
    }
  });
});

//Authenticate
router.post('/authenticate', (req, res, next) => {
  const username = req.body.username;
  const password = req.body.password;

  User.getUserByUsername(username, (err, user) => {
    if(err) throw err;
    if(!user) {
      return res.json({success: false, msg: 'User not found'});
    }

    User.comparePassword(password, user.password, (err, isMatch) => {
      if(err) throw err;
      if(isMatch) {
        const token = jwt.sign({data: user}, config.secret, {
          expiresIn: 604800 // 1 week
        });
        res.json({
          success: true,
          token: 'Bearer ' +token,
          user: {
            id: user._id,
            name: user.name,
            username: user.username,
            email: user.email
          }
        })
      } else {
        return res.json({success: false, msg: 'Wrong password'});
      }
    });
  });
});

//Profile
router.get('/profile', passport.authenticate('jwt', {session:false}), (req, res, next) => {
  res.json({user: req.user});
});

router.get('/getJobs', (req, res, next) => {
  var MongoClient = require('mongodb').MongoClient;
  var url = "mongodb://localhost:27017/";
  
  MongoClient.connect(url,{ useNewUrlParser: true }, function(err, db) {
    if (err) throw err;
    var dbo = db.db("meanauth");
    dbo.collection("posts").find({}).toArray(function(err, result) {
      if (err) throw err;
      console.log(result);
      res.json({
        success: true,
        data: result
      })
      db.close();
    });
  });
});
router.get('/getprofile', passport.authenticate('jwt', {session:false}),(req, res, next) => {
 var doc_id=req.user._id;
 console.log(doc_id);
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url,{ useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("meanauth");
  dbo.collection("Profiles").findOne({_id: doc_id}, function(err, result) {
    if (err) throw err;
    res.json({
      success: true,
      data: result
    })
    db.close();
  });
});
});
router.post('/RegisterProfiles', passport.authenticate('jwt', {session:false}),(req, res, next) => {
  

  let newProfile = new Profile ({
    name :req.name ,
   email :req.email ,
   qualification :req.qualification ,
   Intrests :req.Intrests ,
   Company_name : req.Company_name ,
   Position :req.Position ,
   Mobile_number :req.Mobile_number ,
   Work_address :req.Work_address
  });
  var MongoClient = require('mongodb').MongoClient;
  var url = "mongodb://localhost:27017/";
  
  MongoClient.connect(url,{ useNewUrlParser: true }, function(err, db) {
    if (err) throw err;
    var dbo = db.db("meanauth");
    dbo.collection('Profiles').insertOne(newProfile,function(err, result) {
      if (err) throw err;
      console.log(result);
      res.json({
        success: true,
        data: result
      })
      db.close();
    });
  });
});
module.exports = router;
