const express = require('express');
var nodemailer = require("nodemailer");
var session = require('express-session');
var userInViews = require('./lib/middleware/userInViews');
var authRouter = require('./routes/auth');
var indexRouter = require('./routes/index');
var jobController = require('./controllers/jobController');
var usersRouter = require('./routes/users')
const path = require('path');
const assert = require('assert') ;
const bodyParser = require('body-parser');
const cors = require('cors');
const passport = require('passport');
const mongoose = require('mongoose');
const user=require('./models/user');
const config = require('./config/database');
const jwt = require('jsonwebtoken');
url='mongodb://localhost:27017/meanauth';

mongoose.connect(config.database, { useNewUrlParser: true });
// On Connection
mongoose.connection.on('connected', () => {
  console.log('Connected to Database '+config.database);
});
// On Error
mongoose.connection.on('error', (err) => {
  console.log('Database error '+err);
});

const app = express();
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');
const users = require('./routes/users');

// Port Number
const port = 3000;

// CORS Middleware
app.use(cors());

// Set Static Folder
app.use(express.static(path.join(__dirname, 'public')));

// Body Parser Middleware
app.use(bodyParser.json());
// app.js


// config express-session
var sess = {
  secret: 'CHANGE THIS TO A RANDOM SECRET',
  cookie: {},
  resave: false,
  saveUninitialized: true
};

if (app.get('env') === 'production') {
  sess.cookie.secure = true; // serve secure cookies, requires https
}

app.use(session(sess));

// app.js

// Load environment variables from .env
var dotenv = require('dotenv');
dotenv.config();

// Load Passport
var Auth0Strategy = require('passport-auth0');

// Configure Passport to use Auth0
var strategy = new Auth0Strategy(
  {
    domain: process.env.AUTH0_DOMAIN,
    clientID: process.env.AUTH0_CLIENT_ID,
    clientSecret: process.env.AUTH0_CLIENT_SECRET,
    callbackURL:
      process.env.AUTH0_CALLBACK_URL || 'http://localhost:3000/callback'
  },
  function (accessToken, refreshToken, extraParams, profile, done) {
    // accessToken is the token to call Auth0 API (not needed in the most cases)
    // extraParams.id_token has the JSON Web Token
    // profile has all the information from the user
    return done(null, profile);
  }
);

passport.use(strategy);

app.use(passport.initialize());
app.use(passport.session());

//Passport Middleware

// app.js

// You can use this section to keep a smaller payload
passport.serializeUser(function (user, done) {
  done(null, user);
});

passport.deserializeUser(function (user, done) {
  done(null, user);
});
app.use(userInViews());
app.use('/', authRouter);
app.use('/', indexRouter);
app.use('/', usersRouter);
app.use('/users',users);
app.use('/jobs', jobController);


app.get('/:email',(req,res)=>{
  user.find({email:req.params.email},function(err,registrations){
     // res.json(registrations);
     //console.log(registrations+"  "+err);
      if(err){
          console.log(err);
          res.status(400).send(err);
      }else if(registrations.length>0){
          let transporter = nodemailer.createTransport({
              host: 'smtp.gmail.com',
              port: 465,
              secure: true,
              auth: {
                  type: 'OAuth2',
                  user: 'safiurrehmankhan4@gmail.com',
                  accessToken: 'ya29.GlsAB3VJdYhnxRh-p67EMVrPJ7cxDId7GgR9fHVlt-R0KzO4NYcU9rDzEo8kKwYy-qvvywLTK7S1dbQyIYfaEgpURA9uxzn0K3Z7afgktYHmml1mPxnhSWilx_vW'
             }
          });
          
          console.log("email sending");
          var mailOptions= {
              from : 'safiurrehmankhan4@gmail.com',
              to: req.params.email,
              subject: 'Nodemailer',
              text: registrations[0].password
          }
          transporter.sendMail(mailOptions,function(err,res){
              if(err){
                  console.log(err);
              }else{
                  console.log('email sent!!'+res);
              }
          });
      }
  });
  //res.send("welcome to nuces backend");
});
app.get('/', (req, res) => {
  res.send('invaild endpoint');
});
app.get('/api', (req, res) => {
    res.json({
        message:'Welcome to my api'
    });
  });

app.post('/api/posts', verifyToken, (req, res) => {
    jwt.verify(req.token,'secretkey',(err,authData)=>{
        if(err)
        {
            res.sendStatus(403);
        }
        else
        {
            res.json({
                message: 'past created',
                authData
            });
        }
    })
    res.json({
        message:'Welcome to my posts'
    });
  });

app.post('/api/login',  (req, res) => {
    const user1= {
        id : 1,
        username:"safi",
        email:"safi@gamil.com"
    }
    jwt.sign({user1},'secretkey',(err,token)=>{
        res.json({
            token
        });
    }
    )
  });  

  app.get('/sendEmail',function(req,res){
      res.sendfile('index.html');
  });
  app.get('/send',function(req,res){
      var mailOptions={
          to : req.query.to,
          subject : req.query.subject,
          text : req.query.text
      }
      console.log(mailOptions);
      smtpTransport.sendMail(mailOptions, function(error, response){
       if(error){
              console.log(error);
          res.end("error");
       }else{
              console.log("Message sent: " + response.message);
          res.end("sent");
           }
  });
  });
//app.get('*', (req, res) => {
//  res.sendFile(path.join(__dirname, 'public/index.html'));
//});

// Start Server
app.listen(port, () => {
  console.log('Server started on port '+port);
});

function verifyToken(req,res,next)
{
    const BearerHeader= req.headers['authorization']
    if (typeof BearerHeader !== 'undefined')
    {
        const bearer = BearerHeader.split(' ');
        const bearerToken = bearer[1];
        req.token=bearerToken;
        next();
    }
    else
    {
        res.sendStatus(403);
    }
}

